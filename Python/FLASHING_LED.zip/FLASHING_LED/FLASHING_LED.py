# -*- coding: utf-8 -*-
# Αναβοσβήνει το LED για πάντα
# Σταματάει πατώντας CTRL + c

# gpio 18 --> output (LED)

from gpiozero import LED
from time import sleep

led = LED(18)

try:
  while True:
     led.on()
     sleep(0.5)
     led.off()
     sleep(0.5)
except KeyboardInterrupt:
    led.off()

