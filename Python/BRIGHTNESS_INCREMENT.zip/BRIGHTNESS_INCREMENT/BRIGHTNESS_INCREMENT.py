# -*- coding: utf-8 -*-
# Αυξάνει την ένταση του LED κάθε φορά που πιέζεται το BUTTON
# Σταματάει πατώντας CTRL + c

# gpio 18 --> output (LED)
# gpio 14 <-- input (BUTTON)

from gpiozero import PWMLED, Button
from time import sleep

button = Button(14)
led = PWMLED(18)
led.value = 0

try:
 while True:
   if button.is_pressed and (led.value < 0.99):
     sleep(0.2)
     led.value = led.value + 0.1
     print (led.value)
except KeyboardInterrupt:
    led.off()


