# -*- coding: utf-8 -*-
# Περιστρέφει το servo από τη μικρότερη θέση του (0)
# στη μεγαλύτερη θέση (120) με βήμα 10 και αντίστροφα

# gpio 17 --> output (servo control)


from gpiozero import AngularServo
from time import sleep

servo = AngularServo(17, min_angle=0, max_angle=120)

try:
    for step in range (0,120,10):
        servo.angle = step
        sleep(0.5)
        
    for step in range (120,0,-10):
        servo.angle = step
        sleep(0.5)

    servo.detach()
    
except KeyboardInterrupt:
    servo.detach()
