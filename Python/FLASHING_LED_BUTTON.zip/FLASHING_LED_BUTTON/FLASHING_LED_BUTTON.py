# -*- coding: utf-8 -*-
# Αναβοσβήνει το LED 3 φορές πατώντας το BUTTON
# Σταματάει πατώντας CTRL + c

# gpio 18 --> output (LED)
# gpio 14 <-- input (BUTTON)

from gpiozero import LED, Button
from time import sleep

led = LED(18)
button = Button(14)

try:
 while True:
    if button.is_pressed:
      for x in range (0,3):
        led.on()
        sleep(0.5)
        led.off()
        sleep(0.5)
except KeyboardInterrupt:
    led.off()

