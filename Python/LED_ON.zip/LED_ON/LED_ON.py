# -*- coding: utf-8 -*-
# Ανάβει το LED και παραμένει αναμμένο
# Σταματάει πατώντας CTRL + c

# gpio 18 --> output (LED)

from gpiozero import LED
from time import sleep

led = LED(18)

try:
  while True:
    led.on()
except KeyboardInterrupt:
    led.off()

