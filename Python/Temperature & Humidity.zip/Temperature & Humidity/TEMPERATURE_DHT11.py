# -*- coding: utf-8 -*-
# Εμφανίζει δεδομένα υγρασίας (%) και θερμοκρασίας (βαθμοί Κελσίου)

# gpio 14 <-- input (data)

import Adafruit_DHT 

sensor = 11
pin = 14

humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

print("humidity: ",humidity)
print("Temperature: ", temperature)
